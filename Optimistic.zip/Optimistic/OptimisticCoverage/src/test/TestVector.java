package test;
import logic.Vector;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestVector {

	@Test
	void testFillVector() {
		
		
		
		
		
		int[] vec=new int[4];
		vec[0]=1;
		vec[1]=2;
		vec[2]=3;
		vec[3]=4;
		
		Vector v=new Vector();
		boolean fill=v.fillVector(vec);
		
		
		assertEquals(true,fill);
		
		
		
		
	
	
	
	}

}
