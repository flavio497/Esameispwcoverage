package logic;

public class Vector {
	
	int[] vector=new int[4];
	
	
	
	public boolean fillVector (int[] v){
		
		
	
		for(int i=0;i<4;i++) {
			vector[i]=v[i];
			
			
		}
		return true;
		
	}
	
	

}
